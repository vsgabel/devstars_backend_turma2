$env:DATABASE_URI="mysql://aula:123456@localhost:3306/hospital"
$env:FLASK_CONFIG="development"
$env:FLASK_APP="manage.py"
$env:FLASK_DEBUG=1